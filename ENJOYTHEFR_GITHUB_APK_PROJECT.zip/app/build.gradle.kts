plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.enjoythefr.vr"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.enjoythefr.vr"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
