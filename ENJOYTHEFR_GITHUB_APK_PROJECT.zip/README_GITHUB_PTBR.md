# ENJOYTHEFR — gerar APK pelo GitHub usando o celular

Este repositório contém um app Android nativo (WebView em tela cheia) com a interface VR V2 incluída dentro do APK. Não precisa publicar no Netlify.

## Como gerar o APK
1. No celular, entre em https://github.com e crie uma conta ou entre.
2. Toque em **+** → **New repository**.
3. Nome: `ENJOYTHEFR`, marque **Public** ou **Private**, e crie o repositório.
4. Envie todos os arquivos e pastas deste projeto para o repositório (não envie apenas o ZIP).
   - Se estiver no navegador do celular, use **Add file → Upload files** e selecione os arquivos extraídos.
   - Preserve a pasta `.github/workflows`.
5. Abra a aba **Actions** do repositório.
6. Se pedir, toque em **I understand my workflows, go ahead and enable them**.
7. Escolha **Build ENJOYTHEFR APK** → **Run workflow**.
8. Aguarde ficar verde. Abra a execução concluída e baixe o artefato **ENJOYTHEFR-APK**.
9. Extraia o ZIP baixado: dentro estará `app-debug.apk`. Toque nele para instalar.

## O que esta primeira versão faz
- App Android instalável em tela cheia e orientação horizontal.
- Interface Home, Apps, Browser, Hand Tracking, Games, Quick Menu e Settings.
- Câmera pode ser solicitada pelo app para teste.

## Limitações honestas desta primeira versão
- Hand Tracking ainda não reconhece esqueleto/gestos; só abre a câmera.
- Modo duas lentes é duplicação visual 2D, não renderização 3D VR real.
- Browser abre sites externamente.
- Os cards de jogos são demonstrações, não incluem jogos comerciais.
- Para publicar na Play Store será necessário preparar assinatura e ficha do app.
